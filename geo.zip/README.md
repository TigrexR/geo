##

- redis作为缓存和sesion共享数据库
- mysql、mybatis、mybatis-plus 作为正常数据库连接，持久化数据
- elasticsearch作为