package com.tigrex.geo.config;

// @Configuration
// @EnableRedisHttpSession
public class RedisConfig {

}
