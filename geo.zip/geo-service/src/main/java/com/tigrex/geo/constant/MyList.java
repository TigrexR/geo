package com.tigrex.geo.constant;

import java.util.Collection;

public interface MyList<E> extends Collection<E> {

    @Override
    boolean isEmpty();

}
