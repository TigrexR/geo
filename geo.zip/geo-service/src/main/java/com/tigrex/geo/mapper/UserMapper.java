package com.tigrex.geo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tigrex.geo.entity.po.User;

/**
 * userMapper接口
 * @author linus
 */
public interface UserMapper extends BaseMapper<User> {
}