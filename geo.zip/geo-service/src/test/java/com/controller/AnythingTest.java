package com.controller;

import org.junit.jupiter.api.Test;

public class AnythingTest {

    @Test
    public void main(){}

}
