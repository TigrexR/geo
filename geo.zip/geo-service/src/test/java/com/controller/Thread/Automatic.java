package com.controller.Thread;

import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;

public class Automatic {

    @Test
    public void automaticTest () {
        AtomicInteger ai = new AtomicInteger();
    }
}
