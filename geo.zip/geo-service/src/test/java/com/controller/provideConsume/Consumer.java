package com.controller.provideConsume;

public class Consumer {



}
