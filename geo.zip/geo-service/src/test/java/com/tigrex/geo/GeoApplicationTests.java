package com.tigrex.geo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GeoApplicationTests {

	@Test
	public void contextLoads() {

		System.out.println("hello world!");

	}

}
